# Gestão Executiva — Estética Automotiva

Primeira versão funcional, standalone e sem backend.

## Como executar

1. Extraia o ZIP.
2. Abra `index.html` no navegador.
3. Para testar rapidamente, clique em **Carregar demonstração**.
4. Para começar do zero, use **Limpar dados**.

## Recursos incluídos

- Dashboard executivo
- Receitas, despesas e investimentos
- Saldo bruto e líquido
- Fluxo financeiro básico
- Produtos e estoque
- Status automático: crítico / razoável / ótimo
- Compras
- Clientes
- Veículos
- Serviços
- Ordens de serviço
- Funcionários
- Horas trabalhadas e custo de mão de obra
- Máquinas
- Metas
- Relatórios
- Gráficos
- Dark/light mode
- Backup e restauração JSON
- Persistência no navegador
- Responsividade

## Observação

A versão inicial usa LocalStorage e CDN para Chart.js, Lucide e fonte Inter. Para uso empresarial real com múltiplos usuários, recomenda-se uma segunda etapa com autenticação e banco de dados.
